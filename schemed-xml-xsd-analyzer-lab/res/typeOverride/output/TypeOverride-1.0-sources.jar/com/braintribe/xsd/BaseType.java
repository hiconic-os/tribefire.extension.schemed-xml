package com.braintribe.xsd;

import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;

public interface BaseType extends GenericEntity {

	EntityType<BaseType> T = EntityTypes.T(BaseType.class);

	String first = "first";

	String getFirst();
	void setFirst(String first);

}