package com.braintribe.xsd;

import com.braintribe.model.generic.annotation.GlobalId;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;

public interface DerivationA extends BaseType {

	EntityType<DerivationA> T = EntityTypes.T(DerivationA.class);

	String derivedA = "derivedA";

	@GlobalId("property:com.braintribe.xsd.vt_type_BaseType_extension/derivedA")
	String getDerivedA();
	void setDerivedA(String derivedA);

}