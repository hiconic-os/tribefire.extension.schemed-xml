package com.braintribe.xsd;

import com.braintribe.model.generic.annotation.GlobalId;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;

public interface DerivationB extends BaseType {

	EntityType<DerivationB> T = EntityTypes.T(DerivationB.class);

	String derivedB = "derivedB";

	@GlobalId("property:com.braintribe.xsd.vt_type_BaseType_extension_1/derivedB")
	String getDerivedB();
	void setDerivedB(String derivedB);

}