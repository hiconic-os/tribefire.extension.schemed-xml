package com.braintribe.xsd;

import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;

import java.util.List;

public interface RootType extends GenericEntity {

	EntityType<RootType> T = EntityTypes.T(RootType.class);

	String firsts = "firsts";
	String seconds = "seconds";

	List<BaseType> getFirsts();
	void setFirsts(List<BaseType> firsts);

	List<BaseType> getSeconds();
	void setSeconds(List<BaseType> seconds);

}